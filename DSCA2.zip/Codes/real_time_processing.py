from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

print("[INFO] Initializing Spark Session...")
spark = SparkSession.builder \
    .appName("Darooghe Real-Time Processor") \
    .config("spark.sql.streaming.checkpointLocation", "D:/UT/Semester_8/DataScience/CAs/CA2/Codes/output/checkpoint") \
    .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.0") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")
print("[INFO] Spark Session started.")

schema = StructType() \
    .add("transaction_id", StringType()) \
    .add("timestamp", TimestampType()) \
    .add("customer_id", StringType()) \
    .add("merchant_id", StringType()) \
    .add("merchant_category", StringType()) \
    .add("payment_method", StringType()) \
    .add("amount", IntegerType()) \
    .add("location", StructType().add("lat", FloatType()).add("lng", FloatType())) \
    .add("device_info", StructType().add("os", StringType()).add("app_version", StringType()).add("device_model", StringType())) \
    .add("status", StringType()) \
    .add("commission_type", StringType()) \
    .add("commission_amount", IntegerType()) \
    .add("vat_amount", IntegerType()) \
    .add("total_amount", IntegerType()) \
    .add("customer_type", StringType()) \
    .add("risk_level", IntegerType()) \
    .add("failure_reason", StringType())

print("[INFO] Reading from Kafka topic darooghe.transactions...")
kafka_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "127.0.0.1:9092") \
    .option("subscribe", "darooghe.transactions") \
    .option("startingOffsets", "latest") \
    .load()

parsed_df = kafka_df.selectExpr("CAST(value AS STRING)") \
    .select(from_json("value", schema).alias("data")) \
    .select("data.*")

# === FRAUD DETECTION ===
print("[INFO] Applying Fraud Detection Rules...")
velocity_alerts = parsed_df \
    .withWatermark("timestamp", "2 minutes") \
    .groupBy(window("timestamp", "2 minutes", "20 seconds"), "customer_id") \
    .count() \
    .filter("count > 5") \
    .selectExpr("customer_id as key", "to_json(named_struct('rule', 'velocity', 'customer_id', customer_id, 'tx_count', count)) as value")

geo_df = parsed_df \
    .withWatermark("timestamp", "5 minutes") \
    .select("customer_id", col("timestamp").alias("ts"), "location.lat", "location.lng")

geo_join = geo_df.alias("a").join(
    geo_df.alias("b"),
    (col("a.customer_id") == col("b.customer_id")) &
    (col("a.ts") < col("b.ts")) &
    (col("b.ts").cast("long") - col("a.ts").cast("long") <= 300)
)

geo_alerts = geo_join \
    .withColumn("distance", expr("6371 * 2 * ASIN(SQRT(POW(SIN(RADIANS(b.lat - a.lat) / 2), 2) + COS(RADIANS(a.lat)) * COS(RADIANS(b.lat)) * POW(SIN(RADIANS(b.lng - a.lng) / 2), 2)))")) \
    .filter(col("distance") > 50) \
    .selectExpr("a.customer_id as key", "to_json(named_struct('rule', 'geo_distance', 'customer_id', a.customer_id, 'distance', distance)) as value")

customer_avg_df = parsed_df.withColumn("avg_amount", lit(500000))
amount_anomaly = customer_avg_df \
    .filter(col("amount") > col("avg_amount") * 10) \
    .selectExpr("customer_id as key", "to_json(named_struct('rule', 'amount_anomaly', 'customer_id', customer_id, 'amount', amount, 'avg_amount', avg_amount)) as value")

# === COMMISSION ANALYTICS ===
print("[INFO] Performing Commission Analytics...")
commission_agg = parsed_df \
    .withWatermark("timestamp", "1 minute") \
    .groupBy(window("timestamp", "1 minute", "20 seconds"), "commission_type") \
    .agg(sum("commission_amount").alias("total_commission")) \
    .selectExpr("commission_type as key", "to_json(named_struct('type', commission_type, 'total', total_commission)) as value")

commission_ratio = parsed_df \
    .filter(col("amount") > 0) \
    .withColumn("ratio", col("commission_amount") / col("amount")) \
    .groupBy(window("timestamp", "1 minute", "20 seconds"), "merchant_category") \
    .agg(avg("ratio").alias("avg_ratio")) \
    .selectExpr("merchant_category as key", "to_json(named_struct('category', merchant_category, 'avg_ratio', avg_ratio)) as value")

top_merchants = parsed_df \
    .withWatermark("timestamp", "5 minutes") \
    .groupBy(window("timestamp", "5 minutes", "1 minute"), "merchant_id") \
    .agg(sum("commission_amount").alias("total_commission")) \
    .orderBy(col("total_commission").desc()) \
    .selectExpr("merchant_id as key", "to_json(named_struct('merchant_id', merchant_id, 'total_commission', total_commission)) as value")

# === WRITING TO KAFKA ===
print("[INFO] Writing streams to Kafka topics...")
velocity_alerts.writeStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "127.0.0.1:9092") \
    .option("topic", "darooghe.fraud_alerts") \
    .option("checkpointLocation", "D:/UT/Semester_8/DataScience/CAs/CA2/Codes/output/fraud_checkpoint") \
    .option("failOnDataLoss", "false") \
    .outputMode("update") \
    .start()

geo_alerts.writeStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "127.0.0.1:9092") \
    .option("topic", "darooghe.fraud_alerts") \
    .option("checkpointLocation", "D:/UT/Semester_8/DataScience/CAs/CA2/Codes/output/geo_checkpoint") \
    .option("failOnDataLoss", "false") \
    .outputMode("append") \
    .start()

amount_anomaly.writeStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "127.0.0.1:9092") \
    .option("topic", "darooghe.fraud_alerts") \
    .option("checkpointLocation", "D:/UT/Semester_8/DataScience/CAs/CA2/Codes/output/anomaly_checkpoint") \
    .option("failOnDataLoss", "false") \
    .outputMode("append") \
    .start()

commission_agg.writeStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "127.0.0.1:9092") \
    .option("topic", "darooghe.analytics") \
    .option("checkpointLocation", "D:/UT/Semester_8/DataScience/CAs/CA2/Codes/output/analytics_checkpoint") \
    .option("failOnDataLoss", "false") \
    .outputMode("update") \
    .start()

commission_ratio.writeStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "127.0.0.1:9092") \
    .option("topic", "darooghe.analytics") \
    .option("checkpointLocation", "D:/UT/Semester_8/DataScience/CAs/CA2/Codes/output/ratio_checkpoint") \
    .option("failOnDataLoss", "false") \
    .outputMode("update") \
    .start()

top_merchants.writeStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "127.0.0.1:9092") \
    .option("topic", "darooghe.analytics") \
    .option("checkpointLocation", "D:/UT/Semester_8/DataScience/CAs/CA2/Codes/output/top_merchants_checkpoint") \
    .option("failOnDataLoss", "false") \
    .outputMode("complete") \
    .start()

print("[INFO] Streaming jobs started. Awaiting termination...")
spark.streams.awaitAnyTermination()
