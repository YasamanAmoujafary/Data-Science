import json
import logging
from dataclasses import dataclass
from typing import Optional, Dict
from datetime import datetime, timedelta, timezone
from confluent_kafka import Consumer, Producer
from dateutil import parser as date_parser
from pymongo import MongoClient
from bson import ObjectId

# Logging setup
logging.basicConfig(level=logging.INFO)

# Custom JSON encoder for ObjectId
class JSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        return json.JSONEncoder.default(self, o)

# Connect to MongoDB
mongo_client = MongoClient("mongodb://localhost:27017/")
db = mongo_client["darooghe"]
collection = db["transactions"]

# Kafka config
BROKER = 'localhost:9092'
SOURCE_TOPIC = 'darooghe.transactions'
ERROR_TOPIC = 'darooghe.error_logs'
GROUP_ID = 'validator_group'

# Consumer setup
consumer_conf = {
    'bootstrap.servers': BROKER,
    'group.id': GROUP_ID,
    'auto.offset.reset': 'earliest'
}
consumer = Consumer(consumer_conf)
consumer.subscribe([SOURCE_TOPIC])

# Producer setup
producer = Producer({'bootstrap.servers': BROKER})

# Schema definition
@dataclass
class Transaction:
    transaction_id: str
    timestamp: str
    customer_id: str
    merchant_id: str
    merchant_category: str
    payment_method: str
    amount: int
    vat_amount: int
    commission_amount: int
    total_amount: int
    location: Dict[str, float]
    device_info: Dict[str, str]
    status: str
    commission_type: str
    customer_type: str
    risk_level: int
    failure_reason: Optional[str] = None

# Schema + type validation
def parse_transaction(data: dict) -> Optional[Transaction]:
    try:
        data['amount'] = int(data['amount'])
        data['vat_amount'] = int(data['vat_amount'])
        data['commission_amount'] = int(data['commission_amount'])
        data['total_amount'] = int(data['total_amount'])
        data['risk_level'] = int(data['risk_level'])

        # Validate nested objects
        assert isinstance(data['location'], dict)
        assert isinstance(data['device_info'], dict)
        
        # Validate timestamp format
        _ = date_parser.isoparse(data['timestamp'])

        return Transaction(**data)

    except Exception as e:
        logging.error(f"[SCHEMA ERROR] {e}")
        return None

# Validation rules
def is_valid_amount_consistency(event: Transaction):
    return event.total_amount == event.amount + event.vat_amount + event.commission_amount

def is_valid_timestamp(event: Transaction):
    now = datetime.now(timezone.utc)
    try:
        ts = date_parser.isoparse(event.timestamp)
        return now - timedelta(days=1) <= ts <= now
    except Exception as e:
        logging.error(f"[TIME ERROR] Failed to parse timestamp: {e}")
        return False

def is_valid_device(event: Transaction):
    if event.payment_method == "mobile":
        return event.device_info.get("os") in ["iOS", "Android"]
    return True


# Error handler
def publish_error(event: dict, error_code: str):
    error_message = {
        'transaction_id': event.get('transaction_id', 'UNKNOWN'),
        'error_code': error_code,
        'event': event
    }
    producer.produce(ERROR_TOPIC, key=error_message['transaction_id'], value=json.dumps(error_message))
    producer.flush()
    logging.warning(f"[INVALID] {error_code} for transaction {error_message['transaction_id']}")

# Main loop
printed = False
try:
    while True:
        msg = consumer.poll(1.0)
        if msg is None:
            continue
        if msg.error():
            logging.error(f"Consumer error: {msg.error()}")
            continue

        try:
            raw_event = json.loads(msg.value())
        except json.JSONDecodeError as e:
            logging.error(f"JSON decode error: {e}")
            continue

        event = parse_transaction(raw_event)
        if not event:
            publish_error(raw_event, 'ERR_SCHEMA')
            continue

        if not is_valid_amount_consistency(event):
            publish_error(raw_event, 'ERR_AMOUNT')
        elif not is_valid_timestamp(event):
            publish_error(raw_event, 'ERR_TIME')
        elif not is_valid_device(event):
            publish_error(raw_event, 'ERR_DEVICE')
        else:
            collection.insert_one(raw_event)
            if not printed:
                logging.info(f"[VALID] Transaction ID: {event.transaction_id}")
                print(JSONEncoder().encode(raw_event))
                printed = True

except KeyboardInterrupt:
    pass
finally:
    consumer.close()
