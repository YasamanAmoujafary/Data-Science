import json
from collections import deque, Counter, defaultdict
from datetime import datetime
import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
from kafka import KafkaConsumer
from kafka.errors import KafkaError
from pymongo import MongoClient
import time

# === CONFIG ===
KAFKA_TOPICS = ["darooghe.transactions", "darooghe.fraud_alerts", "darooghe.analytics"]
KAFKA_SERVER = "127.0.0.1:9092"
MONGO_URI = "mongodb://localhost:27017/"
MAX_POINTS = 100
DB_NAME = "darooghe"

# === STATE ===
transaction_counts = deque(maxlen=MAX_POINTS)
time_labels = deque(maxlen=MAX_POINTS)
merchant_counter = Counter()
user_counter = Counter()
fraud_alerts = deque(maxlen=50)
commission_ratios = defaultdict(list)
timestamps_seen = set()

# === MONGO CLIENT ===
mongo_client = MongoClient(MONGO_URI)
db = mongo_client[DB_NAME]

# === KAFKA CONSUMER ===
def create_consumer():
    """Create and return a Kafka consumer with retries."""
    consumer = None
    retries = 5
    for attempt in range(retries):
        try:
            consumer = KafkaConsumer(
                *KAFKA_TOPICS,
                bootstrap_servers=KAFKA_SERVER,
                auto_offset_reset="latest",
                enable_auto_commit=True,
                group_id="dash-visualizer",
                value_deserializer=lambda v: json.loads(v.decode("utf-8")),
                consumer_timeout_ms=5000  # Increased timeout for retries
            )
            print("Kafka consumer connected.")
            return consumer
        except KafkaError as e:
            print(f"Kafka consumer connection error: {e}. Retrying in 5 seconds...")
            time.sleep(5)
    raise Exception("Failed to connect to Kafka broker after multiple retries.")

# Create the consumer with retry logic
consumer = create_consumer()

# === DASH APP ===
app = dash.Dash(__name__)
app.title = "Darooghe Real-Time Dashboard"

app.layout = html.Div([
    html.H1("📊 Darooghe Real-Time Transaction Dashboard", style={'textAlign': 'center'}),
    
    html.H2("Transaction Volume"),
    dcc.Graph(id='volume-chart'),
    dcc.Graph(id='historical-volume-chart'),

    html.H2("Merchant Analysis"),
    dcc.Graph(id='merchant-chart'),
    dcc.Graph(id='merchant-category-chart'),

    html.H2("User Activity"),
    dcc.Graph(id='user-chart'),
    dcc.Graph(id='user-segment-chart'),

    html.H2("Fraud Alerts"),
    dcc.Graph(id='fraud-chart'),

    html.H2("Commission Analytics"),
    dcc.Graph(id='commission-ratio-chart'),

    dcc.Interval(id='interval-component', interval=3000, n_intervals=0)
])

@app.callback(
    [
        Output('volume-chart', 'figure'),
        Output('historical-volume-chart', 'figure'),
        Output('merchant-chart', 'figure'),
        Output('merchant-category-chart', 'figure'),
        Output('user-chart', 'figure'),
        Output('user-segment-chart', 'figure'),
        Output('fraud-chart', 'figure'),
        Output('commission-ratio-chart', 'figure')
    ],
    [Input('interval-component', 'n_intervals')]
)
def update_graphs(n):
    try:
        for msg in consumer:
            topic = msg.topic
            data = msg.value

            if topic == "darooghe.transactions":
                ts = data.get("timestamp")
                if ts:
                    try:
                        ts = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                        bucket = ts.strftime("%Y-%m-%d %H:%M")
                        if bucket not in timestamps_seen:
                            timestamps_seen.add(bucket)
                            time_labels.append(bucket)
                            transaction_counts.append(1)
                        else:
                            transaction_counts[-1] += 1
                    except Exception as e:
                        print("Timestamp parse error:", e)

                merchant = data.get("merchant_id")
                customer = data.get("customer_id")
                if merchant:
                    merchant_counter[merchant] += 1
                if customer:
                    user_counter[customer] += 1

            elif topic == "darooghe.fraud_alerts":
                fraud_alerts.append({
                    "rule": data.get("rule"),
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "details": data
                })

            elif topic == "darooghe.analytics":
                if "avg_ratio" in data:
                    category = data.get("category")
                    ratio = data.get("avg_ratio")
                    commission_ratios[category].append({
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M"),
                        "ratio": ratio
                    })
    except Exception as e:
        print("Kafka consume error:", e)

    # Mongo queries
    temporal_patterns = list(db.temporal_patterns.find().sort("hour", 1))
    category_behavior = list(db.category_behavior.find())
    customer_segments = list(db.customer_segments.find())

    # 1. Real-time volume
    volume_fig = go.Figure([go.Scatter(
        x=list(time_labels) or ["No Data"],
        y=list(transaction_counts) or [0],
        mode='lines+markers',
        name='Transactions per Minute',
        line=dict(color='blue')
    )])
    volume_fig.update_layout(title="Real-Time Transaction Volume", xaxis_title="Time", yaxis_title="Count")

    # 2. Historical volume (hourly)
    hist_hours = [str(p.get("hour")) for p in temporal_patterns]
    hist_counts = [p.get("transaction_count", 0) for p in temporal_patterns]
    hist_fig = go.Figure([go.Bar(x=hist_hours, y=hist_counts, marker_color='green')])
    hist_fig.update_layout(title="Historical Transactions by Hour", xaxis_title="Hour", yaxis_title="Transactions")

    # 3. Top merchants
    top_merchants = merchant_counter.most_common(5)
    merchant_fig = go.Figure([go.Bar(
        x=[m[1] for m in top_merchants],
        y=[m[0] for m in top_merchants],
        orientation='h',
        marker_color='purple'
    )])
    merchant_fig.update_layout(title="Top Merchants", xaxis_title="Transactions", yaxis_title="Merchant ID")

    # 4. Category distribution
    cat_counts = [c.get("transaction_count", 0) for c in category_behavior]
    cat_labels = [c.get("merchant_category", "Unknown") for c in category_behavior]
    cat_fig = go.Figure([go.Pie(labels=cat_labels, values=cat_counts, hole=0.3)])
    cat_fig.update_layout(title="Transaction Share by Category")

    # 5. Top users
    top_users = user_counter.most_common(5)
    user_fig = go.Figure([go.Bar(
        x=[u[0] for u in top_users],
        y=[u[1] for u in top_users],
        marker_color='orange'
    )])
    user_fig.update_layout(title="Top Users", xaxis_title="User ID", yaxis_title="Transactions")

    # 6. User segments
    segment_counts = Counter([s.get("segment", "Unknown") for s in customer_segments])
    segment_fig = go.Figure([go.Pie(
        labels=list(segment_counts.keys()),
        values=list(segment_counts.values()),
        hole=0.3
    )])
    segment_fig.update_layout(title="Customer Segments")

    # 7. Fraud alert count
    fraud_rules = [f["rule"] for f in fraud_alerts]
    fraud_counts = Counter(fraud_rules)
    fraud_fig = go.Figure([go.Bar(
        x=list(fraud_counts.keys()),
        y=list(fraud_counts.values()),
        marker_color='red'
    )])
    fraud_fig.update_layout(title="Fraud Alerts", xaxis_title="Rule", yaxis_title="Count")

    # 8. Commission ratios
    ratio_fig = go.Figure()
    for cat, entries in commission_ratios.items():
        times = [e["timestamp"] for e in entries][-MAX_POINTS:]
        values = [e["ratio"] for e in entries][-MAX_POINTS:]
        ratio_fig.add_trace(go.Scatter(x=times, y=values, mode='lines+markers', name=cat))
    ratio_fig.update_layout(title="Commission Ratios by Category", xaxis_title="Time", yaxis_title="Ratio")

    return volume_fig, hist_fig, merchant_fig, cat_fig, user_fig, segment_fig, fraud_fig, ratio_fig

if __name__ == "__main__":
    app.run(debug=True)
